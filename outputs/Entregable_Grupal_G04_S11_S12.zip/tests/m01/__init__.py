"""Tests for M01."""
